---
name: wechat-mcp
description: Use when accessing WeChat Official Account articles and content via MCP tools - provides 5 tools for reading account info, listing articles, fetching article content, and searching public WeChat articles
metadata:
  author: 42ailab
  version: '1.0'
  title: 微信公众号 MCP 工具使用指南
  description_zh: 通过 MCP 工具访问微信公众号文章内容，包含官方 API 和搜狗搜索两条数据通道，提供5个核心工具的使用规范
---

# 微信公众号 MCP 工具使用指南

## 概述

本 MCP Server 提供5个工具访问微信公众号内容，分为两条数据通道：
- **官方 API 通道**（需要 `WECHAT_APPID` + `WECHAT_SECRET`）：访问自己管理的公众号
- **搜狗搜索通道**（无需凭据）：搜索任意公众号的公开文章

## 使用时机

- 用户要查看某个微信公众号的文章列表或内容
- 用户要搜索微信公众号上的文章
- 用户要获取某篇微信文章的全文
- 调试微信公众号 API 配置是否正确

不适用于：
- 发布或修改微信公众号内容（只读功能）
- 获取非公众号类型的微信内容（朋友圈、群聊等）

## 快速参考

| 工具 | 数据源 | 需要凭据 | 主要用途 |
|------|--------|----------|----------|
| `get_account_info` | 官方 API | 是 | 验证配置、查看账号状态 |
| `list_articles` | 官方 API | 是 | 获取本号文章列表（分页） |
| `get_article_content` | 官方 API | 是 | 按 media_id 读取文章全文 |
| `search_public_articles` | 搜狗搜索 | 否 | 搜索任意公众号文章 |
| `get_public_article_content` | 搜狗抓取 | 否 | 读取公开文章全文（有反爬风险） |

## 五个工具详解

### 1. get_account_info — 获取公众号基本信息

首次使用前运行，验证 API 配置是否正确。

```
get_account_info(format="json", detail="concise")
get_account_info(format="markdown", detail="detailed")
```

**参数：**
- `format`: `json`（默认）或 `markdown`
- `detail`: `concise`（默认，基本信息）或 `detailed`（含完整统计）

**返回：** 账号类型、认证状态、素材数量统计、API 配额信息

**常见错误：**
- 配置缺失 → 检查 `WECHAT_APPID` 和 `WECHAT_SECRET` 环境变量
- 认证失败 → 确认公众号已认证并开启开发者模式
- IP 白名单 → 服务器 IP 需加入微信公众平台白名单

---

### 2. list_articles — 获取文章列表

列出自己公众号发布的图文消息，支持分页。**注意：每日调用上限 10 次。**

```
list_articles(offset=0, count=10, format="json", detail="concise")
list_articles(offset=10, count=5, format="markdown", detail="detailed")
```

**参数：**
- `offset`: 分页偏移量（从0开始）
- `count`: 每页数量，最大 20
- `format` / `detail`: 同上

**返回：** 文章标题、作者、摘要、`media_id`、更新时间

**关键：** 返回的 `media_id` 用于调用 `get_article_content`

---

### 3. get_article_content — 获取文章全文

根据 `media_id` 读取文章完整内容。`media_id` 必须先从 `list_articles` 获取。

```
get_article_content(media_id="BM_Vc7h...", format="markdown", detail="detailed")
get_article_content(media_id="BM_Vc7h...", format="json", include_html=True)
```

**参数：**
- `media_id`: 必填，从 `list_articles` 返回结果中获取
- `format`: `markdown`（默认推荐）或 `json`
- `detail`: `detailed`（默认）或 `concise`
- `include_html`: 是否返回原始 HTML（仅 json 格式有效，默认 false）

**返回：** 标题、作者、正文、字数、预估阅读时间

---

### 4. search_public_articles — 搜索公开文章

通过搜狗微信搜索，查找任意公众号的公开文章。无需配置凭据。

```
search_public_articles(query="人工智能", limit=10)
search_public_articles(query="ChatGPT", account_name="机器之心", limit=5)
```

**参数：**
- `query`: 搜索关键词（必填，1-100字）
- `account_name`: 限定公众号名称（可选）
- `limit`: 返回数量，最大 20（默认 10）
- `format` / `detail`: 同上

**返回：** 文章标题、公众号名称、发布时间、文章 URL

**反爬注意：**
- 搜索频率过快会触发限制，每次间隔至少 30 秒
- 被封锁后等待 5-30 分钟再重试
- 关键词尽量简短精确

---

### 5. get_public_article_content — 获取公开文章全文

根据 URL 抓取公开文章内容。URL 来自 `search_public_articles` 结果。**高风险操作，可能不稳定。**

```
get_public_article_content(article_url="https://mp.weixin.qq.com/s/xxx")
get_public_article_content(article_url="https://mp.weixin.qq.com/s/xxx", extract_images=True)
```

**参数：**
- `article_url`: 必填，格式必须为 `https://mp.weixin.qq.com/s/...`
- `format`: `markdown`（默认推荐）或 `json`
- `detail`: `detailed`（默认）或 `concise`
- `extract_images`: 是否提取图片链接（默认 false）

**返回：** 标题、作者、正文、发布时间

**注意：** 微信反爬机制较强，失败后等待 10-30 分钟再重试。优先用 `search_public_articles` 获取摘要。

---

## 典型工作流

### 查阅自己公众号文章

```
1. get_account_info()          # 验证配置
2. list_articles(offset=0, count=20)  # 获取文章列表和 media_id
3. get_article_content(media_id="...") # 读取具体文章
```

### 搜索外部公众号文章

```
1. search_public_articles(query="关键词", account_name="公众号名")  # 搜索
2. get_public_article_content(article_url="...")  # 读取全文（可选）
```

## 常见错误

| 错误 | 原因 | 解决方案 |
|------|------|----------|
| 环境变量未设置 | 缺少 APPID/SECRET | 检查 `.env` 或系统环境变量 |
| API 超出调用限制 | 素材管理 10次/天上限 | 第二天重试，或优化调用频率 |
| 搜索触发反爬 | 搜狗频率限制 | 等待 5-30 分钟后重试 |
| media_id 无效 | ID 不正确或文章已删除 | 重新调用 list_articles 获取 |
| 文章内容过长 | 超过 25,000 token 限制 | 使用 `detail="concise"` 模式 |
